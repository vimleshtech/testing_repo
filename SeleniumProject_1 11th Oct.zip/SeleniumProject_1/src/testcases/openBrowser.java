package testcases;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class openBrowser {

	public static void main(String[] args) throws IOException {
		
		////
		
		WebDriver d = new ChromeDriver();
		d.get("https://www.google.com/");
		
		String url,title;
		
		title = d.getTitle();
		url = d.getCurrentUrl();
		
		System.out.println("page title is: "+title);
		System.out.println("page url is: "+url);
		
		//event 
		d.findElement(By.id("lst-ib")).sendKeys("Selenium code");;
		d.findElement(By.id("lst-ib")).sendKeys(Keys.ENTER);
		
		//capture screen/take screenshot
		File src =	((TakesScreenshot)d).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File("C:\\Users\\Tech Vision\\Desktop\\Selenium Setup\\out.png"));	
	
		
		
		////
		
	}
}
