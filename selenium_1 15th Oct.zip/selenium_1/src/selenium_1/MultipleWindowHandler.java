package selenium_1;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MultipleWindowHandler {

	public static void main(String[] args) {

		
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.naukri.com/");
		
	  Set<String> wins=	driver.getWindowHandles();  //return list of windows
	  
	  System.out.println(wins.size());
	  
	  for(String win : wins ) //: iterator 
	  {
		  	driver.switchTo().window(win);
		  	String title  = driver.getTitle();
		  	System.out.println(title);
		  	
		  	
		  	if(title.startsWith("Amazon"))
		  		driver.findElement(By.xpath("/html/body/a/img")).click();
		  	
	  }
		
		
		
		
		

	}

}
