package selenium_1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class yahooGetText {

	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();

		driver.get("https://www.yahoo.com/");
		//Here List is collection(multiple values)
		//WebElement : is class type for HTML Element 
		//List<WebElement>
		List<WebElement> els = 	driver.findElements(By.tagName("a"));
		
		System.out.println(els.size());
		
		for(int i=0; i<els.size();i++)
		{
			String msg =	els.get(i).getText();
			System.out.println(msg);
		
			if(msg.contains("Sign in"))
				els.get(i).click();
			
		}	
		

	}

}
