package selenium_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class alertHandler {

	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.naukri.com/");
		
		driver.findElement(By.id("tryit")).click();
		
		String msg = driver.switchTo().alert().getText();
		System.out.println(msg);
		
		//driver.switchTo().alert().dismiss(); //cancel 
		driver.switchTo().alert().accept();  //ok 
		
		

	}

}
